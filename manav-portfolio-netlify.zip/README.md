# Manav Verma Portfolio

Premium modern developer portfolio built with:

- Next.js
- TypeScript
- Tailwind CSS
- Framer Motion

## Run Locally

```bash
npm install
npm run dev
```

## Production Build

```bash
npm run build
npm start
```

export const personalInfo = {
  name: "Manav Verma",
  title: "Shopify & WooCommerce Developer | E-commerce Specialist",
  tagline: "Building High-Converting Shopify & WooCommerce Experiences",
  experience: "1.5+ Years",
  projectsDelivered: "100+",
  location: "Delhi, India",
  phone: "+91 9625031604",
  email: "varmamanav095@gmail.com"
};

export const skills = [
  { name: "Shopify", level: 95 },
  { name: "WooCommerce", level: 90 },
  { name: "Shopify Liquid", level: 92 },
  { name: "Theme Customization", level: 94 },
  { name: "Metafields & Metaobjects", level: 88 },
  { name: "Landing Pages", level: 91 },
  { name: "Cart Customization", level: 89 },
  { name: "Payment & Shipping Integrations", level: 90 }
];

export const services = [
  "Shopify Development",
  "WooCommerce Development",
  "Store Setup",
  "Landing Page Development",
  "Store Optimization"
];

export const highlights = [
  "100+ Projects Delivered",
  "End-to-End Store Setup",
  "Shopify Expertise",
  "Fast Delivery"
];

export const projects = [
  {
    title: "Naintara India",
    description: "Premium jewelry e-commerce experience optimized for conversions and mobile shopping.",
    url: "https://naintaraindia.com",
    image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=1600&q=80",
    stack: ["Shopify", "Liquid", "Custom Sections"]
  },
  {
    title: "Babe Couture",
    description: "Fashion storefront with high-impact visuals, collection filtering, and fast checkout journey.",
    url: "https://babecouture.in",
    image: "https://images.unsplash.com/photo-1445205170230-053b83016050?w=1600&q=80",
    stack: ["Shopify", "Theme Customization", "Responsive Design"]
  },
  {
    title: "Hair You Go",
    description: "Beauty commerce build with custom product pages and trust-focused purchase flow.",
    url: "https://hairyougo.co.in",
    image: "https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=1600&q=80",
    stack: ["WooCommerce", "UI/UX", "Payment Integration"]
  },
  {
    title: "House of Fitoor India",
    description: "Lifestyle and fashion storefront with polished catalog structure and conversion-first design.",
    url: "https://houseoffitoorindia.com",
    image: "https://images.unsplash.com/photo-1472851294608-062f824d29cc?w=1600&q=80",
    stack: ["Shopify", "Landing Pages", "Store Optimization"]
  },
  {
    title: "Tyas",
    description: "Modern e-commerce setup tailored for D2C scale, speed, and smooth content management.",
    url: "https://tyas.in",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=1600&q=80",
    stack: ["Shopify", "Metafields", "Custom Sections"]
  },
  {
    title: "Dopamine Shop",
    description: "Vibrant lifestyle store engineered for fast browsing and high engagement interactions.",
    url: "https://dopamineshop.in",
    image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=1600&q=80",
    stack: ["Shopify", "Liquid", "Performance"]
  },
  {
    title: "Ghuri by Debjani",
    description: "Elegant brand presentation with custom storytelling blocks and premium shopping journey.",
    url: "https://www.ghuribydebjani.com",
    image: "https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1600&q=80",
    stack: ["WooCommerce", "Custom Pages", "Responsive Design"]
  },
  {
    title: "Blaqhorse",
    description: "Minimal yet bold commerce site balancing design aesthetics with seamless functionality.",
    url: "https://blaqhorse.com",
    image: "https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=1600&q=80",
    stack: ["Shopify", "Theme Customization", "Checkout UX"]
  },
  {
    title: "The Nail Expressions",
    description: "Beauty-focused storefront with optimized product discovery and mobile-first experience.",
    url: "https://thenailexpressions.com",
    image: "https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?w=1600&q=80",
    stack: ["Shopify", "Product Pages", "Shipping Integration"]
  }
];

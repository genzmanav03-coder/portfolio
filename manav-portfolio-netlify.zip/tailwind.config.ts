import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}"
  ],
  theme: {
    extend: {
      colors: {
        background: "#070b14",
        card: "#0f162a",
        accent: "#22d3ee",
        accent2: "#a78bfa",
        foreground: "#e5e7eb",
        muted: "#9ca3af"
      },
      boxShadow: {
        glow: "0 0 40px rgba(34, 211, 238, 0.18)"
      },
      backgroundImage: {
        "hero-gradient":
          "radial-gradient(circle at 20% 20%, rgba(34, 211, 238, 0.25), transparent 30%), radial-gradient(circle at 80% 0%, rgba(167, 139, 250, 0.25), transparent 30%), linear-gradient(180deg, #070b14 0%, #05070d 100%)"
      }
    }
  },
  plugins: []
};

export default config;

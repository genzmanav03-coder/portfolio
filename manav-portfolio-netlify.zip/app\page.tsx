import { ArrowRight, BriefcaseBusiness, MapPin, Mail, Phone } from "lucide-react";
import { AnimatedCounter } from "@/components/animated-counter";
import { Navbar } from "@/components/navbar";
import { ProjectCard } from "@/components/project-card";
import { Reveal } from "@/components/reveal";
import { SectionTitle } from "@/components/section-title";
import { highlights, personalInfo, projects, services, skills } from "@/data/portfolio";

export default function Home() {
  return (
    <main className="min-h-screen bg-hero-gradient">
      <Navbar />

      <section className="section-wrap py-20 sm:py-28">
        <Reveal>
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-2 text-xs text-slate-200">
            <MapPin size={14} /> {personalInfo.location}
          </p>
          <h1 className="max-w-4xl text-4xl font-bold leading-tight text-white sm:text-6xl">
            {personalInfo.name}
            <span className="mt-2 block bg-gradient-to-r from-accent via-cyan-200 to-accent2 bg-clip-text text-transparent">
              {personalInfo.title}
            </span>
          </h1>
          <p className="mt-6 max-w-2xl text-lg text-slate-300">{personalInfo.tagline}</p>
          <div className="mt-8 flex flex-wrap gap-4">
            <a href="#projects" className="rounded-xl bg-accent px-6 py-3 text-sm font-semibold text-slate-900 transition hover:bg-cyan-300">
              View Projects
            </a>
            <a href="#contact" className="rounded-xl border border-white/20 bg-white/5 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/10">
              Contact Me
            </a>
          </div>
        </Reveal>
        <div className="mt-12 grid gap-4 sm:grid-cols-2">
          <AnimatedCounter value={100} label="Projects Delivered" />
          <AnimatedCounter value={15} label="Months of Experience" suffix="+" />
        </div>
      </section>

      <section id="about" className="section-wrap py-16">
        <Reveal>
          <SectionTitle eyebrow="About" title="Building conversion-first e-commerce experiences" />
          <div className="glass rounded-2xl p-7 text-slate-300">
            I am a Shopify & WooCommerce Developer with 1.5+ years of experience building, customizing, and
            managing e-commerce websites for D2C brands. I specialize in Shopify theme customization, Shopify
            Liquid development, custom sections, metafields, payment gateway integrations, shipping integrations,
            landing page development, and complete store launches. I have contributed to 100+ e-commerce projects
            across fashion, beauty, jewelry, personal care, and lifestyle brands.
          </div>
        </Reveal>
      </section>

      <section id="skills" className="section-wrap py-16">
        <SectionTitle eyebrow="Skills" title="Core technologies and capabilities" />
        <div className="grid gap-4 md:grid-cols-2">
          {skills.map((skill, i) => (
            <Reveal key={skill.name} delay={i * 0.05}>
              <div className="glass rounded-2xl p-5">
                <div className="mb-3 flex items-center justify-between">
                  <p className="font-medium text-white">{skill.name}</p>
                  <p className="text-sm text-muted">{skill.level}%</p>
                </div>
                <div className="h-2 rounded-full bg-white/10">
                  <div className="h-full rounded-full bg-gradient-to-r from-accent to-accent2" style={{ width: `${skill.level}%` }} />
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="experience" className="section-wrap py-16">
        <SectionTitle eyebrow="Experience" title="Professional timeline" />
        <Reveal>
          <div className="glass relative rounded-2xl p-6">
            <div className="absolute bottom-6 left-8 top-6 w-px bg-white/20" />
            <div className="relative pl-8">
              <span className="absolute left-0 top-2 h-3 w-3 rounded-full bg-accent" />
              <p className="text-sm text-accent">Feb 2025 - Present</p>
              <h3 className="mt-1 text-xl font-semibold text-white">Marketo Adverto</h3>
              <p className="mt-2 text-muted">Shopify & WooCommerce Developer focused on end-to-end D2C store delivery.</p>
            </div>
          </div>
        </Reveal>
      </section>

      <section id="projects" className="section-wrap py-16">
        <SectionTitle eyebrow="Featured Projects" title="Selected e-commerce builds" subtitle="Premium project showcase with modern UI, conversion focus, and scalable architecture." />
        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
          {projects.map((project, i) => (
            <Reveal key={project.title} delay={i * 0.04}>
              <ProjectCard project={project} />
            </Reveal>
          ))}
        </div>
      </section>

      <section id="services" className="section-wrap py-16">
        <SectionTitle eyebrow="Services" title="What I can build for your brand" />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, i) => (
            <Reveal key={service} delay={i * 0.05}>
              <div className="glass rounded-2xl p-6">
                <BriefcaseBusiness className="mb-3 text-accent" />
                <h3 className="text-lg font-semibold text-white">{service}</h3>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="why-hire" className="section-wrap py-16">
        <SectionTitle eyebrow="Why Hire Me" title="Reliable e-commerce execution, from idea to launch" />
        <div className="grid gap-4 sm:grid-cols-2">
          {highlights.map((item, i) => (
            <Reveal key={item} delay={i * 0.06}>
              <div className="glass flex items-center justify-between rounded-2xl p-5">
                <p className="font-medium text-white">{item}</p>
                <ArrowRight className="text-accent" size={18} />
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      <section id="contact" className="section-wrap py-16">
        <SectionTitle eyebrow="Contact" title="Let's build your next high-converting store" />
        <Reveal>
          <div className="glass rounded-2xl p-7">
            <div className="grid gap-4 sm:grid-cols-2">
              <a href={`tel:${personalInfo.phone}`} className="rounded-xl border border-white/10 bg-white/5 p-4 text-slate-200 transition hover:bg-white/10">
                <Phone className="mb-2 text-accent" size={18} />
                {personalInfo.phone}
              </a>
              <a href={`mailto:${personalInfo.email}`} className="rounded-xl border border-white/10 bg-white/5 p-4 text-slate-200 transition hover:bg-white/10">
                <Mail className="mb-2 text-accent" size={18} />
                {personalInfo.email}
              </a>
            </div>
          </div>
        </Reveal>
      </section>

      <footer className="section-wrap pb-10 pt-4">
        <div className="border-t border-white/10 pt-6 text-center text-sm text-muted">
          © {new Date().getFullYear()} {personalInfo.name}. Crafted with Next.js, TypeScript, Tailwind CSS, and Framer Motion.
        </div>
      </footer>
    </main>
  );
}

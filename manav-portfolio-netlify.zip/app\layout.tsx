import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Manav Verma | Shopify & WooCommerce Developer",
  description:
    "Premium developer portfolio of Manav Verma, Shopify & WooCommerce Developer building high-converting e-commerce experiences.",
  keywords: [
    "Shopify Developer",
    "WooCommerce Developer",
    "E-commerce Specialist",
    "Shopify Liquid",
    "Delhi India"
  ],
  openGraph: {
    title: "Manav Verma | Shopify & WooCommerce Developer",
    description:
      "Building high-converting Shopify & WooCommerce experiences for modern D2C brands.",
    type: "website"
  }
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

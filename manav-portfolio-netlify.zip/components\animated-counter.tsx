"use client";

import { useEffect, useRef, useState } from "react";

type CounterProps = {
  value: number;
  label: string;
  suffix?: string;
};

export function AnimatedCounter({ value, label, suffix = "+" }: CounterProps) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement | null>(null);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setStarted(true);
          observer.disconnect();
        }
      },
      { threshold: 0.4 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    let current = 0;
    const step = Math.max(1, Math.floor(value / 60));
    const timer = setInterval(() => {
      current += step;
      if (current >= value) {
        setCount(value);
        clearInterval(timer);
      } else {
        setCount(current);
      }
    }, 22);
    return () => clearInterval(timer);
  }, [started, value]);

  return (
    <div ref={ref} className="glass rounded-2xl p-5 text-center shadow-glow">
      <p className="text-3xl font-bold text-white">
        {count}
        {suffix}
      </p>
      <p className="mt-1 text-sm text-muted">{label}</p>
    </div>
  );
}

"use client";

import Link from "next/link";
import { Menu } from "lucide-react";
import { useState } from "react";

const links = [
  { href: "#about", label: "About" },
  { href: "#skills", label: "Skills" },
  { href: "#projects", label: "Projects" },
  { href: "#services", label: "Services" },
  { href: "#contact", label: "Contact" }
];

export function Navbar() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-background/70 backdrop-blur-xl">
      <div className="section-wrap flex h-16 items-center justify-between">
        <Link href="#" className="text-lg font-semibold text-white">
          Manav Verma
        </Link>
        <nav className="hidden items-center gap-7 md:flex">
          {links.map((link) => (
            <a key={link.href} href={link.href} className="text-sm text-muted transition hover:text-white">
              {link.label}
            </a>
          ))}
        </nav>
        <button className="text-white md:hidden" onClick={() => setOpen((v) => !v)} aria-label="menu">
          <Menu size={22} />
        </button>
      </div>
      {open && (
        <div className="section-wrap pb-4 md:hidden">
          <div className="glass rounded-xl p-3">
            {links.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="block rounded-lg px-3 py-2 text-sm text-muted hover:bg-white/10 hover:text-white"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

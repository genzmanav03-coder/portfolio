/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "images.unsplash.com" },
      { protocol: "https", hostname: "www.naintaraindia.com" },
      { protocol: "https", hostname: "babecouture.in" },
      { protocol: "https", hostname: "hairyougo.co.in" },
      { protocol: "https", hostname: "houseoffitoorindia.com" },
      { protocol: "https", hostname: "tyas.in" },
      { protocol: "https", hostname: "dopamineshop.in" },
      { protocol: "https", hostname: "www.ghuribydebjani.com" },
      { protocol: "https", hostname: "blaqhorse.com" },
      { protocol: "https", hostname: "thenailexpressions.com" }
    ]
  }
};

export default nextConfig;
